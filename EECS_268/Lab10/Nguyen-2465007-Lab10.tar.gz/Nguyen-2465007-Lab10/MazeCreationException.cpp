//Filename: MazeCreationException.h
//Description: MazeCreation class definitions
//Assignment: EECS 268 Lab 10
//Author: Henry C. Nguyen
//Email: h724n828@ku.edu
//Date: 5-8-2014
//

#include "MazeCreationException.h"
